export class Popup {
    constructor(className) {
        this._className = className;
        this.popup = document.querySelector(`.${className}`)
        this._handleEscUp = this._handleEscUp.bind(this);
    }

    _handleEscUp(evt) { // по нажатию на escape закрываем popup
        if (evt.key === 'Escape') {
            this.close()
        }
    }

    open() { // добавляем класс active и открываем popup
        this.popup.classList.add('popup_active');
        document.addEventListener('keyup', this._handleEscUp);
    }

    close() { //удаляем класс active и закрываем popup
        this.popup.classList.remove('popup_active')
        document.removeEventListener('keyup', this._handleEscUp)
    }

    setContent(contentNode) {
        const containerContent = this.popup.querySelector('.popup__content');
        containerContent.innerHTML = '';
        containerContent.append(contentNode);
    }

    setEventListener(){
        this.popup.addEventListener('click', (evt) => {
            if (evt.target.classList.contains(this._className) || evt.target.closest('.popup__close')) {
                this.close();
            }
        })
    }
}