export class Card {
    constructor(
        dataCat, 
        selectorTemplate, 
        handleCatImage, 
        handleCatTitle,
        handleCatLike,
        ) {
        this._dataCat = dataCat;
        this._selectorTemplate = selectorTemplate;
        this._handleCatImage = handleCatImage;
        this._handleCatTitle = handleCatTitle;
        this._handleCatLike = handleCatLike;
    }

    _getTemplate() { // возвращает содержимое <template> (шаблона) в виде DOM-узла
        return document.querySelector(this._selectorTemplate).content.querySelector('.card');
    
    }

    getElement() {
        this.element = this._getTemplate().cloneNode(true); // клонируем полученное содержимое из шаблона
        this.cardTitle = this.element.querySelector('.card__name'); // достаём имя
        this.cardImage = this.element.querySelector('.card__image'); // достаём аватар
        this.cardLike = this.element.querySelector('.card__like'); // достаём лайк

        
        if (this._dataCat.favourite) {
            this.cardLike.classList.toggle('card__like_active')
            // cardLike.remove() можно в элс чтоб удалить серые лайки
        }

        this.updateView();

        this.setEventListener()

        return this.element
    }

    getData () { // переносит данные из карточки в модальное окно
        return this._dataCat;
    }

    getId() { // возвращает id карточки
        return this._dataCat.id;
    }

    setData(newData) { // новые данные 
        this._dataCat = newData;
    }

    updateView() { 
        this.cardTitle.textContent = this._dataCat.name;
        this.cardImage.src = this._dataCat.image;
    }
    
    deleteView() { // удаление карточки с данными о коте
        this.element.remove()
        this.element = null;
    }

    setEventListener() { // обработчик событий по клику, вызывает модальное окно, в которое передаются данные о кое
        this.cardImage.addEventListener('click', () => this._handleCatImage(this._dataCat));
        this.cardTitle.addEventListener('click', () => this._handleCatTitle(this));
    }
    
}

